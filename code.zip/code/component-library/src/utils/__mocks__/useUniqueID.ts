export const useUniqueID = (): string => 'unique-id';
