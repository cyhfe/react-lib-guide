import { createContext } from 'react';

export const FieldContext = createContext<string | undefined>(undefined);
